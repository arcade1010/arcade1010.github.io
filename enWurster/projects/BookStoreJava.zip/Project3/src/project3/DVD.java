public class DVD extends Product{
    //Constructor
    public DVD(String title, int price, boolean sold){
        super(title, price, sold);
    }
    
}