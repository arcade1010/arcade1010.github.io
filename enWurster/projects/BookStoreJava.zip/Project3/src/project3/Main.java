import java.util.Scanner;
import java.util.ArrayList;
public class Main {

    public static void main(String[] args) {
        //data fields
        //User Name
        String name;
        //book title
        String title;
        //free or premium input
        String fop =  "free";
        //isMember check
        boolean isMember;
        //input for main UI when asked what you would like to do?
        int whatDo;
        //title of products to compare
        Product prodTemp1;
        Product prodTemp2;
        String prodName1;
        String prodName2;
        //change membership input check
        String changeMembershipCheck;
        


        //Initiallize bookstore store and its products
        BookStore store = new BookStore();
        store.initProducts();
        store.updateInventory();
        
        store.printInventory();
        //Initial input for name
        System.out.println("Welcome to the bookstore! What's your name?");
        Scanner input = new Scanner(System.in);
        name = input.next();
        //search for name
        isMember = store.isMember(name);
        //Creates new membership
        if (isMember == false){
            System.out.println("We couldn't find a membership with that name. Would you like to make a free or premium membership?(Enter 'free' or 'premium')");
            fop = input.next();
            //creates free membership and adds to memberList
            if (fop.equals("free")){
                store.newMember(false, name, 0);
                System.out.println("We made a free membership under the name: " + name);
                
            }
            //creates pMember and adds to pMemberList, also takes payInfo to store in PremiumMember, also adds 5 to spent
            else if (fop.equals("premium")){
                store.newMember(true, name, 5);
                System.out.println("We made a premium membership under the name: " + name + ". Also a $5 charge will be applied to your account. How would you like to pay today?(debit, credit, paypal)");
                String payInfo = input.next();
                store.setPaymentInfo(name, payInfo);
            }
            else{
                System.out.println("Please enter 'free' or 'premium'");
            }
        }
        else{
            System.out.println("Welcome back " + name + ".");
        }

        
        //Loop until user enters 0
        do {
            //Main UI
        //What would you like to do?
        System.out.println("---------------");
        System.out.println("What would you like to do?");
        System.out.println("Buy a product: [1]");
        System.out.println("See how much you've spent: [2]");
        System.out.println("Change membership type: [3]");
        System.out.println("Compare the price of two products: [4]");
        System.out.println("Restock a product and display inventory as well as total value of the inventory: [5]");
        
        System.out.println("Exit [0]");
        whatDo = input.nextInt();

        switch (whatDo) {
            case 1:
                store.printInventory();
                System.out.println();
                System.out.println("Name the product you want to buy and press enter.");
                title = input.next();
                store.purchase(name, title);
                break;
            case 2:
                System.out.println("You have spent: $" + store.getMemberSpent(name));
                break;
            case 3:
                System.out.println("You have a " + fop + " membership. Are you sure you want to change? [yes] or [no]");
                changeMembershipCheck = input.next();
                if(changeMembershipCheck.equals("yes")){
                    store.changeMembershipType(name);
                }
                break;
            case 4:
                System.out.println("What's the first product's title you'd like to compare the price of? ");
                prodName1 = input.next();
                System.out.println("What's the second product's title you'd like to compare the price of? ");
                prodName2 = input.next();
                store.getProductObj(prodName1).display();
                store.getProductObj(prodName2).display();
                
                int result = store.getProductObj(prodName1).compareTo(store.getProductObj(prodName2));
                
                
                if (result == 1)
                    System.out.println(prodName1 + " is more expensive.");
                else if (result == -1)
                    System.out.println(prodName2 + " is more expensive.");
                else 
                    System.out.println("The two products are priced the same.");
                break;
            case 5:
                System.out.println("What's the title of the product you want to restock?");
                title = input.next();
                int indexTemp = store.getIndexOfProduct(title);
                store.restockProduct(indexTemp, 0);
                System.out.println("The item has been restocked. Here's the current inventory.");
                store.printInventory();
                System.out.println("Valued at: " + store.inventoryValue());
                break;
            case 0:
                System.out.println("Goodbye");
                store.updateInventory();
                System.out.println("Inventory.txt has been updated");
                store.endOfDayReport();
                System.out.println("End of day Report has been created");
            default:
                break;
        }


        } while (whatDo != 0);

        

        //Prints done
        System.out.print("done");
        
    }
}
