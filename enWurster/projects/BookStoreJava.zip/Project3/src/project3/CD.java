public class CD extends Product{
    //Constructor
    public CD(String title, int price, boolean sold){
        super(title, price, sold);
    }
    
}