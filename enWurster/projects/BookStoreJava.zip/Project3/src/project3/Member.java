import java.util.ArrayList;
public class Member{
    //data fields
    private String name;
    private int spent=0;
    
    //Constructor
    public Member(String name, int spent){
        this.name = name;
        this.spent = spent;
    }
    //Getters
    //Data fields
    public String getName(){
        return this.name;
    }
    public int getSpent(){
        return this.spent;
    }

    //Setters
    public void setName(String name){
        this.name=name;
    }
    //adds to member's spent
    public void setSpent(int x){
        spent+=x;
    }
    
}
