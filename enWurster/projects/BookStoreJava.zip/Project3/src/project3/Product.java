/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * Makes all product classes subclasses of this one parent class: Product
 * @author madsk
 */
public class Product implements Comparable<Product>{
     private String title = "";
     private int price;
     private boolean sold;
    
    
    
     public Product(String title, int price, boolean sold){
        this.title = title;
        this.price= price;
        this.sold = sold;
    }
    //Getter
    public String getTitle(){
        return this.title;
    }
    public int getPrice(){
        return this.price;
    }
    public boolean isSold(){
        return this.sold;
    }
    //Setters
    public void setTitle(String t){
        this.title = t;
    }
    public void setPrice(int p){
        this.price = p;
    }
    public void setSold(boolean x){
        this.sold = x;
    }
    
    public void display(){
        System.out.println(" Title: " + this.title + ", Price: " + this.price + ", sold: " + sold);
    }
    //Price compareTp
    
    public int compareTo(Product o){
        Product otherObject = (Product) o;
        int oPrice = otherObject.getPrice();
        if (this.getPrice() == oPrice)
            return 0;
        else if (this.getPrice() > oPrice)
            return 1;
        else
            return -1;
    }
    
}
