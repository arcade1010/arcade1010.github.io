import java.util.ArrayList;
public class PremiumMember{
    //data fields
    private String name;
    private int spent=0;
    private boolean paid = true;
    String paymentInfo;
    
    //Constructor
    public PremiumMember(String name, int spent){
        this.name = name;
        this.spent = spent;
    }
    //Getters
    //Data fields
    public String getName(){
        return name;
    }
    public int getSpent(){
        return spent;
    }
    public boolean isPaid(){
        return paid;
    }
    //get payMentInfo
    public String getPaymentInfo(){
        return paymentInfo;
    }
    //Setters
    //set name
    public void setName(String name){
        this.name=name;
    }
    //adds to PremiumMember's spent
    public void setSpent(int x){
        spent+=x;
    }
    //Set if monthly paid or not
    public void setPaid(boolean torf){
        paid = torf;
    }
    //set payment info
    public void setPaymentInfo(String payInfo){
        paymentInfo = payInfo;
    }
    
}