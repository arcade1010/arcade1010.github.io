public class Book extends Product{
    //Constructor
    public Book(String title, int price, boolean sold){
        super(title, price, sold);
    }
    
    
}