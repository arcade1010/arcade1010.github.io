import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;
public class BookStore implements BookStoreSpecification{
    //fields
    private static ArrayList<String> titles = new ArrayList<String>();
    private static int newMembers = 0;
    private static int totalSales = 0;
    
    
    //Read from inventory file and initialize products
    public void initProducts() {
        
        try (Scanner scanner = new Scanner(new File("inventory.txt"))){
            

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                // use comma as separator
                String[] data = line.split(",");

                if(data[0].equalsIgnoreCase("book")){
                    products.add(new Book(data[1], Integer.parseInt(data[2]), Boolean.parseBoolean(data[3])));
                }
                if(data[0].equalsIgnoreCase("cd")){
                    products.add(new CD(data[1], Integer.parseInt(data[2]), Boolean.parseBoolean(data[3])));
                }
                if(data[0].equalsIgnoreCase("DVD")){
                    products.add(new DVD(data[1], Integer.parseInt(data[2]), Boolean.parseBoolean(data[3])));
                }
            }
            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    //Write to file and update inventory file
    public void updateInventory(){
        PrintWriter  writer;
        try {
            writer = new PrintWriter(new File("inventory.txt"));
            for (Product p : products){
                String info = (p.getClass() + "," + p.getTitle() + "," + p.getPrice() + "," + p.isSold());
                writer.println(info.substring(6));
            }
            writer.close();
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }
    //End Of Day Report
    public void endOfDayReport(){
        PrintWriter writer;
        try {
            writer = new PrintWriter(new File("EODR.txt"));
            writer.print("All products sold: ");
            for (String s : titles){
                writer.print(s+", ");
            }
            writer.print(", new members: " + newMembers + ", total sales for the day: " + totalSales);
            writer.close();
        } catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }
    
    

    //all Products
    static ArrayList<Product> products = new ArrayList<Product>();
    //Getter for products
    public ArrayList<Product> getProducts(){
        return products;
    }
    //index of product
    public int getIndexOfProduct(String title){
        for (int i=0; i<products.size(); i++){
            if (products.get(i).getTitle().equals(title)){
                return i;
            }
        }
        return -1;
    }
    //get Product object from name
    public Product getProductObj(String n){
        int index = getIndexOfProduct(n);
        return products.get(index);
    }
    
    //Constructor
    public BookStore(){

    }   

    
    //Prints current inventory
    public void printInventory(){
        System.out.println("Our selection of products:");
        for (Product p : products){
            p.display();
        }
    }
    
    //Member memberList
    ArrayList<Member> memberList = new ArrayList<Member>();
    //addMember to memberList
    public void addMember(Member x){
        memberList.add(x);
    }
    //PremiumMember pMemberList
    ArrayList<PremiumMember> pMemberList = new ArrayList<PremiumMember>();
    //addPremiumMember to pMemberList
    public void addPremiumMember(PremiumMember x){
        pMemberList.add(x);
    }
    //New Member
    public void newMember(boolean isPremium, String name, int spent){
        if (isPremium==true){
            PremiumMember pMem = new PremiumMember(name, spent);
            pMemberList.add(pMem);
            newMembers+=1;
        }
        else if(isPremium==false){
            Member mem = new Member(name, spent);
            memberList.add(mem);
            newMembers+=1;
        }
    }
    //Check for membership, return false if name not found in either lists
    public boolean isMember(String name){
        for(int i=0; i<memberList.size();i++){
            if(name == memberList.get(i).getName()){
                return true;
            }
        }
        for (int i=0; i<pMemberList.size();i++){
            if(name == memberList.get(i).getName()){
                return true;
            }
        }
        return false;
    }
    //return if member is free or premium
    public String typeOfMembership(String name){
        for(int i=0; i<memberList.size();i++){
            if(name == memberList.get(i).getName()){
                return "free";
            }
        }
        for (int i=0; i<pMemberList.size();i++){
            if(name == pMemberList.get(i).getName()){
                return "premium";
            }
        }
        return "Unknown";
    }
    //return index of member. returns -1 if not found(only called when executing methods with a known member)
    public int indexOfMember(String name){
        for(int i=0; i<memberList.size();i++){
            if(name == memberList.get(i).getName()){
                return i;
            }
        }
        return -1;
    }
    //return index of PremiumMember (virtually same as above method for free members)
    public int indexOfPremiumMember(String name)       {
        for(int i=0; i<pMemberList.size();i++){
            if(name == pMemberList.get(i).getName()){
                return i;
            }
        }
        return -1;        
    } 
    //set payment info
    public void setPaymentInfo(String name, String payInfo){
        int indOfMem = indexOfPremiumMember(name);
        pMemberList.get(indOfMem).setPaymentInfo(payInfo);
    }
    

    //find if product is sold. search each list to match title and check if the object at that index is sold or not
    public boolean isProductSold(String title){
        if (products.get(getIndexOfProduct(title)).isSold())
            return true;
        else 
            return false;                     
    }
    //what type of product (Book, CD or DVD)
    public String typeOfProduct(String title){
        if (products.get(getIndexOfProduct(title)) instanceof Book)
            return "Book";
        else if (products.get(getIndexOfProduct(title)) instanceof CD)
            return "CD";
        else
            return "DVD";
            
    }

    //Complete a purchase. Name of member and title of product. Sets product to sold and adds price to member's spent
    public void purchase(String name, String title){
        //if indexOfProduct cant find product
        int index = (getIndexOfProduct(title));
        if (index == -1){
            System.out.println("We don't have a book with that title.");
        }
        //indexOfProduct found product
        else{
            //check if product is sold
            if(isProductSold(title)){
                System.out.println("Sorry, that product has already been bought.");
            }
            //product is in inventory and not sold.
            else{
                //Sell product
                getProductObj(title).setSold(true);
                //adds money to member's spent
                if(typeOfMembership(name).equals("free")){
                        memberList.get(indexOfMember(name)).setSpent(products.get(index).getPrice());
                    System.out.println("Thank you for your purchase of " + title + "!");
                }
                else if(typeOfMembership(name).equals("premium")){
                    pMemberList.get(indexOfPremiumMember(name)).setSpent(products.get(index).getPrice());
                    System.out.println("Thank you for your purchase!");
                }
                titles.add(title);
                totalSales+=getProductObj(title).getPrice();
            }
        }
    }

    //See how much member has spent
    public int getMemberSpent(String name){
        //free member
        if (typeOfMembership(name).equals("free")){
            return memberList.get(indexOfMember(name)).getSpent();
        }
        //premium member
        else if(typeOfMembership(name).equals("premium")){
            return pMemberList.get(indexOfPremiumMember(name)).getSpent();
        }
        return 0;
    }

    //Change membership type
    public void changeMembershipType(String name){
        int spent;
        //free --> premium
        if (typeOfMembership(name).equals("free")){
            //gets spent for this 
            spent = (memberList.get(indexOfMember(name)).getSpent()) +5;
            //puts old member on pMemberList as new Premium Member
            pMemberList.add(new PremiumMember(name, spent));
            memberList.remove(indexOfMember(name));
            //prints confirmation
            System.out.println("You are now a premium member!");
        }
        //premium --> free
        else if (typeOfMembership(name).equals("premium")){
            //gets spent for this member
            spent = pMemberList.get(indexOfPremiumMember(name)).getSpent();
            //puts old pMember or memberList as new Member
            memberList.add(new Member(name, spent));
            pMemberList.remove(indexOfPremiumMember(name));
            //prints confirmation
            System.out.println("You are now a free member.");
        }

        
        
        
    }

//BookStoreSpecification
        
        public void restockProduct(int index, int happyNum){
            products.get(index).setSold(false);
        }
        public double inventoryValue(){
            double sum = 0;
            for (Product p : products){
                if (p.isSold() == false)
                    sum+= p.getPrice();
            }
            return sum;
        }
       

}